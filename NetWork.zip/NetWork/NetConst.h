






#ifndef NetConst_h
#define NetConst_h

//网络打印
#ifdef DEBUG
#   define NetLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ## __VA_ARGS__);
#else
#   define NetLog(...)
#endif

#define NetShareManager [NetManager sharedNetManager]

#define Weak  __weak __typeof(self) weakSelf = self

/**
 *   当前网络状态的枚举类型
 */
typedef NS_ENUM(NSUInteger, NetworkStatus) {
    /** 未知网络*/
    NetworkStatusUnknown = 0,
    /** 无网络*/
    NetworkStatusNotReachable,
    /** 手机网络*/
    NetworkStatusReachableViaWWAN,
    /** WIFI网络*/
    NetworkStatusReachableViaWiFi
};


/**
 *   请求方式的枚举类型
 */
typedef NS_ENUM(NSUInteger, HttpRequestType)
{
    //get请求
    HttpRequestTypeGet = 0,
    //post请求
    HttpRequestTypePost,
};


/**
 *   请求数据类型的枚举类型
 */
typedef NS_ENUM(NSUInteger, HttpRequestSerializer) {
    //设置请求数据为JSON格式
    HttpRequestSerializerJSON,
    //设置请求数据为HTTP格式
    HttpRequestSerializerHTTP,
};

/**
 *   响应返回数据类型的枚举类型
 */
typedef NS_ENUM(NSUInteger, HttpResponseSerializer) {
    //设置响应数据为JSON格式
    HttpResponseSerializerJSON,
    //设置响应数据为HTTP格式
    HttpResponseSerializerHTTP,
};


/**
 *   实时监测网络状态的 block
 */
typedef void(^NetworkStatusBlock)(NetworkStatus status);


/**
 *   定义请求成功的 block
 */
typedef void(^ResponseSuccess)(id response);

/**
 *   定义请求失败的 block
 */
typedef void(^ResponseFailure)(NSError *error);

/**
 *   定义上传进度的 block
 */
typedef void(^UploadProgress)(int64_t bytesProgress,
int64_t totalBytesProgress);

/**
 *   定义下载进度的 block
 */
typedef void(^DownloadProgress)(int64_t bytesProgress,
int64_t totalBytesProgress);

/*!
 *  方便管理请求任务。执行取消，暂停，继续等任务.
 *  - (void)cancel，取消任务
 *  - (void)suspend，暂停任务
 *  - (void)resume，继续任务
 */
typedef NSURLSessionTask URLSessionTask;

#endif /* NetConst_h */
