






#import "NetManager.h"
#import <AFNetworking.h>
#import <AFNetworkActivityIndicatorManager.h>
#import "NetManagerCache.h"

//网络任务
static NSMutableArray * netTasks;

@interface NetManager()

@property(nonatomic, strong) AFHTTPSessionManager *sessionManager;

@end

@implementation NetManager

+ (instancetype)sharedNetManager
{
    /*! 为单例对象创建的静态实例，置为nil，因为对象的唯一性，必须是static类型 */
    static id sharedNetManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedNetManager = [[super allocWithZone:NULL] init];
    });
    return sharedNetManager;
}

+ (void)initialize
{
    [self setupNetManager];
}

+ (void)setupNetManager
{
    //打开状态栏的等待菊花
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    
    NetShareManager.sessionManager = [AFHTTPSessionManager manager];
    //默认解析模式
    NetShareManager.requestSerializer = HttpRequestSerializerJSON;
    NetShareManager.responseSerializer = HttpResponseSerializerJSON;
    //设置请求的超时时间
    NetShareManager.timeoutInterval = 30;
    //配置响应序列化
    NetShareManager.sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/css", @"text/xml", @"text/plain", @"application/javascript", @"image/*", nil];
    //配置自建的Https请求
    //[self setupSecurityPolicy];
}

/**
 配置自建证书的Https请求，只需要将CA证书文件放入根目录就行
 */
+ (void)setupSecurityPolicy
{
    //    NSData *cerData = [NSData dataWithContentsOfFile:cerPath];
    NSSet <NSData *> *cerSet = [AFSecurityPolicy certificatesInBundle:[NSBundle mainBundle]];
    
    if (cerSet.count == 0)
    {
        /*!
         采用默认的defaultPolicy就可以了. AFN默认的securityPolicy就是它, 不必另写代码. AFSecurityPolicy类中会调用苹果security.framework的机制去自行验证本次请求服务端放回的证书是否是经过正规签名.
         */
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
        securityPolicy.allowInvalidCertificates = YES;
        securityPolicy.validatesDomainName = NO;
        NetShareManager.sessionManager.securityPolicy = securityPolicy;
    }
    else
    {
        /*! 自定义的CA证书配置如下： */
        /*! 自定义security policy, 先前确保你的自定义CA证书已放入工程Bundle */
        /*!
         https://api.github.com网址的证书实际上是正规CADigiCert签发的, 这里把Charles的CA根证书导入系统并设为信任后, 把Charles设为该网址的SSL Proxy (相当于"中间人"), 这样通过代理访问服务器返回将是由Charles伪CA签发的证书.
         */
        // 使用证书验证模式
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate withPinnedCertificates:cerSet];
        // 如果需要验证自建证书(无效证书)，需要设置为YES
        securityPolicy.allowInvalidCertificates = YES;
        // 是否需要验证域名，默认为YES
        //    securityPolicy.pinnedCertificates = [[NSSet alloc] initWithObjects:cerData, nil];
        
        NetShareManager.sessionManager.securityPolicy = securityPolicy;
        
        /*! 如果服务端使用的是正规CA签发的证书, 那么以下几行就可去掉: */
        //            NSSet <NSData *> *cerSet = [AFSecurityPolicy certificatesInBundle:[NSBundle mainBundle]];
        //            AFSecurityPolicy *policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate withPinnedCertificates:cerSet];
        //            policy.allowInvalidCertificates = YES;
        //            BANetManagerShare.sessionManager.securityPolicy = policy;
    }
}


/**
 Get 请求
 
 @param urlString 请求的地址
 @param isCache 是否需要缓存
 @param parameters 请求的参数
 @param successBlock 请求成功的回调
 @param failureBlock 请求失败的回调
 @return URLSessionTask
 */
+ (URLSessionTask *)GetRequestWithUrlString:(NSString *)urlString
                                      isCache:(BOOL)isCache
                                   parameters:(NSDictionary *)parameters
                                 successBlock:(ResponseSuccess)successBlock
                                 failureBlock:(ResponseFailure)failureBlock
{
    return [self requestWithType:HttpRequestTypeGet urlString:urlString isCache:isCache parameters:parameters successBlock:successBlock failureBlock:failureBlock];
}


/**
 Post 请求
 
 @param urlString 请求的地址
 @param isCache 是否需要缓存
 @param parameters 请求的参数
 @param successBlock 请求成功的回调
 @param failureBlock 请求失败的回调
 @return URLSessionTask
 */
+ (URLSessionTask *)PostRequestWithUrlString:(NSString *)urlString
                                       isCache:(BOOL)isCache
                                    parameters:(NSDictionary *)parameters
                                  successBlock:(ResponseSuccess)successBlock
                                  failureBlock:(ResponseFailure)failureBlock
{
    return [self requestWithType:HttpRequestTypePost urlString:urlString isCache:isCache parameters:parameters successBlock:successBlock failureBlock:failureBlock];
}


#pragma mark - 网络请求的实例方法

+ (URLSessionTask *)requestWithType:(HttpRequestType)type
                            urlString:(NSString *)urlString
                              isCache:(BOOL)isCache
                           parameters:(NSDictionary *)parameters
                         successBlock:(ResponseSuccess)successBlock
                         failureBlock:(ResponseFailure)failureBlock
{
    
    if (urlString == nil) {
        
        return nil;
    }
    
    Weak;
    //检查网络地址是否有中文
    NSString *URLString = [NSURL URLWithString:urlString] ? urlString : [self strUTF8Encoding:urlString];
    
    URLSessionTask *sessionTask = nil;
    
    // 读取缓存
    id responseCacheData = [NetManagerCache httpCacheWithUrlString:urlString parameters:parameters];
    
    if (isCache && responseCacheData != nil) {
        
        if (successBlock) {
            successBlock(responseCacheData);
        }
        
        [[weakSelf netTasks] removeObject:sessionTask];
        
        NetLog(@"\n\n----取用缓存数据=%@\n",[self jsonToString:responseCacheData]);
    }
    
    if (type == HttpRequestTypeGet) {
        sessionTask = [NetShareManager.sessionManager GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            if (successBlock) {
                successBlock(responseObject);
            }
            
            // 对数据进行异步缓存
            [NetManagerCache setHttpCache:responseObject urlString:urlString parameters:parameters];
            
            [[weakSelf netTasks] removeObject:sessionTask];
            
            NetLog(@"\n\n----请求的返回结果=%@\n",[self jsonToString:responseObject]);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            if (failureBlock) {
                failureBlock(error);
            }
            [[weakSelf netTasks] removeObject:sessionTask];
        }];
        
    }else if (type == HttpRequestTypePost)
    {
        sessionTask = [NetShareManager.sessionManager POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            if (successBlock) {
                successBlock(responseObject);
            }
            // 对数据进行异步缓存
            [NetManagerCache setHttpCache:responseObject urlString:urlString parameters:parameters];
            [[weakSelf netTasks] removeObject:sessionTask];
            NetLog(@"\n\n----请求的返回结果=%@\n",[self jsonToString:responseObject]);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            if (failureBlock) {
                failureBlock(error);
            }
            [[weakSelf netTasks] removeObject:sessionTask];
        }];
        
    }
    
    if (sessionTask)
    {
        [[weakSelf netTasks] addObject:sessionTask];
    }
    
    return sessionTask;
    
}

/**
 上传多张图片
 
 @param urlString 请求的地址
 @param parameters 请求的参数
 @param imageArray 上传的图片数组
 @param fileNameArray 上传的图片数组对应的名字
 @param successBlock 上传成功的回调
 @param failureBlock 上传失败的回调
 @param progress 上传进度
 @return URLSessionTask
 */
+ (URLSessionTask *)UploadMultipleImageWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                            imageArray:(NSArray *)imageArray
                                         fileNameArray:(NSArray *)fileNameArray
                                          successBlock:(ResponseSuccess)successBlock
                                          failureBlock:(ResponseFailure)failureBlock
                                        upLoadProgress:(UploadProgress)progress
{
    if (urlString == nil) {
        
        return nil;
    }
    
    Weak;
    
    //检查网络地址是否有中文
    NSString *URLString = [NSURL URLWithString:urlString] ? urlString : [self strUTF8Encoding:urlString];
    
    URLSessionTask *sessionTask = nil;
    
    sessionTask = [NetShareManager.sessionManager POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        [imageArray enumerateObjectsUsingBlock:^(UIImage *image, NSUInteger idx, BOOL * _Nonnull stop) {
            
            /*! 此处压缩方法是jpeg格式是原图大小的0.8倍，要调整大小的话，就在这里调整就行了还是原图等比压缩 */
            NSData *imgData = UIImageJPEGRepresentation(image, 0.5);
            
            if (imgData != nil) {
                
                // 可以在上传时使用当前的系统事件作为文件名
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                // 设置时间格式
                [formatter setDateFormat:@"yyyyMMddHHmmss"];
                NSString *dateString = [formatter stringFromDate:[NSDate date]];
                NSString *fileName = [NSString  stringWithFormat:@"%@.jpg", dateString];
                [formData appendPartWithFileData:imgData name:fileNameArray[idx] fileName:fileName mimeType:@"image/png"];
            }
            
        }];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
        NetLog(@"上传进度--%lld,总进度---%lld",uploadProgress.completedUnitCount,uploadProgress.totalUnitCount);
        
        if (progress)
        {
            progress(uploadProgress.completedUnitCount, uploadProgress.totalUnitCount);
        }
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NetLog(@"上传图片成功 = %@",responseObject);
        if (successBlock)
        {
            successBlock(responseObject);
        }
        [[weakSelf netTasks] removeObject:sessionTask];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (failureBlock)
        {
            failureBlock(error);
        }
        [[weakSelf netTasks] removeObject:sessionTask];
    }];
    
    if (sessionTask)
    {
        [[weakSelf netTasks] addObject:sessionTask];
    }
    return sessionTask;
}


/**
 文件下载
 
 @param urlString 请求的地址
 @param parameters 请求的参数
 @param savePath 下载文件保存路径
 @param successBlock 下载文件成功的回调
 @param failureBlock 下载文件失败的回调
 @param progress 下载文件的进度显示
 @return URLSessionTask
 */
+ (URLSessionTask *)DownloadFileWithUrlString:(NSString *)urlString
                                     parameters:(NSDictionary *)parameters
                                       savaPath:(NSString *)savePath
                                   successBlock:(ResponseSuccess)successBlock
                                   failureBlock:(ResponseFailure)failureBlock
                               downLoadProgress:(DownloadProgress)progress
{
    if (urlString == nil)
    {
        return nil;
    }
    
    NSURLRequest *downloadRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    URLSessionTask *sessionTask = nil;
    
    sessionTask = [NetShareManager.sessionManager downloadTaskWithRequest:downloadRequest progress:^(NSProgress * _Nonnull downloadProgress) {
        
        NetLog(@"下载进度：%.2lld%%",100 * downloadProgress.completedUnitCount/downloadProgress.totalUnitCount);
        /*! 回到主线程刷新UI */
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (progress)
            {
                progress(downloadProgress.completedUnitCount, downloadProgress.totalUnitCount);
            }
            
        });
        
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        
        if (!savePath)
        {
            NSURL *downloadURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
            NetLog(@"默认路径--%@",downloadURL);
            return [downloadURL URLByAppendingPathComponent:[response suggestedFilename]];
        }
        else
        {
            return [NSURL fileURLWithPath:savePath];
        }
        
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        
        [[self netTasks] removeObject:sessionTask];
        
        NetLog(@"下载文件成功");
        if (error == nil)
        {
            if (successBlock)
            {
                /*! 返回完整路径 */
                successBlock([filePath path]);
            }
            else
            {
                if (failureBlock)
                {
                    failureBlock(error);
                }
            }
        }
    }];
    
    /*! 开始启动任务 */
    [sessionTask resume];
    
    if (sessionTask)
    {
        [[self netTasks] addObject:sessionTask];
    }
    return sessionTask;

}
#pragma mark - url 中文格式化
+ (NSString *)strUTF8Encoding:(NSString *)str
{
    /*! ios9适配的话 打开第一个 */
    if ([[UIDevice currentDevice] systemVersion].floatValue >= 9.0)
    {
        return [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
    }
    else
    {
        return [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
}


#pragma mark - 网络状态监测

+ (void)startNetWorkMonitoringWithBlock:(NetworkStatusBlock)networkStatus
{
    /*! 1.获得网络监控的管理者 */
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    /*! 2.设置网络状态改变后的处理 */
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /*! 当网络状态改变了, 就会调用这个block */
        switch (status)
        {
            case AFNetworkReachabilityStatusUnknown:
                NetLog(@"未知网络");
                networkStatus ? networkStatus(NetworkStatusUnknown) : nil;
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NetLog(@"没有网络");
                networkStatus ? networkStatus(NetworkStatusNotReachable) : nil;
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NetLog(@"手机自带网络");
                networkStatus ? networkStatus(NetworkStatusReachableViaWWAN) : nil;
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NetLog(@"wifi 网络");
                networkStatus ? networkStatus(NetworkStatusReachableViaWiFi) : nil;
                break;
        }
    }];
    [manager startMonitoring];
}

#pragma mark - 取消 Http 请求
/*!
 *  取消所有 Http 请求
 */
+ (void)cancelAllRequest
{
    // 锁操作
    @synchronized(self)
    {
        [[self netTasks] enumerateObjectsUsingBlock:^(NSURLSessionTask  *_Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            [task cancel];
        }];
        [[self netTasks] removeAllObjects];
    }
}

/*!
 *  取消指定 URL 的 Http 请求
 */
+ (void)cancelRequestWithUrl:(NSString *)url
{
    if (!url)
    {
        return;
    }
    @synchronized (self)
    {
        [[self netTasks] enumerateObjectsUsingBlock:^(NSURLSessionTask  *_Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            
            if ([task.currentRequest.URL.absoluteString hasPrefix:url])
            {
                [task cancel];
                [[self netTasks] removeObject:task];
                *stop = YES;
            }
        }];
    }
}

/**
 *  自定义请求头
 */
+ (void)setValue:(NSString *)value forHTTPHeaderKey:(NSString *)HTTPHeaderKey
{
    [NetShareManager.sessionManager.requestSerializer setValue:value forHTTPHeaderField:HTTPHeaderKey];
}


/**
 *  json转字符串
 */
+ (NSString *)jsonToString:(id)data
{
    if(!data) { return nil; }
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:data options:NSJSONWritingPrettyPrinted error:nil];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}


#pragma mark - Setter/Getter Method
/**
 存储着所有的请求task数组
 
 @return 存储着所有的请求task数组
 */
+ (NSMutableArray *)netTasks
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NetLog(@"创建数组");
        netTasks = [[NSMutableArray alloc] init];
    });
    return netTasks;
}

- (void)setTimeoutInterval:(NSTimeInterval)timeoutInterval
{
    _timeoutInterval = timeoutInterval;
    NetShareManager.sessionManager.requestSerializer.timeoutInterval = timeoutInterval;
}

- (void)setRequestSerializer:(HttpRequestSerializer)requestSerializer
{
    _requestSerializer = requestSerializer;
    switch (requestSerializer) {
        case HttpRequestSerializerJSON:
        {
            NetShareManager.sessionManager.requestSerializer = [AFJSONRequestSerializer serializer] ;
        }
            break;
        case HttpRequestSerializerHTTP:
        {
            NetShareManager.sessionManager.requestSerializer = [AFHTTPRequestSerializer serializer] ;
        }
            break;
            
        default:
            break;
    }

}

- (void)setResponseSerializer:(HttpResponseSerializer)responseSerializer
{
    _responseSerializer = responseSerializer;
    switch (responseSerializer) {
        case HttpResponseSerializerJSON:
        {
            NetShareManager.sessionManager.responseSerializer = [AFJSONResponseSerializer serializer] ;
        }
            break;
        case HttpResponseSerializerHTTP:
        {
            NetShareManager.sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer] ;
        }
            break;
            
        default:
            break;
    }

}

- (void)setHttpHeaderFieldDictionary:(NSDictionary *)httpHeaderFieldDictionary
{
    _httpHeaderFieldDictionary = httpHeaderFieldDictionary;
    if (![httpHeaderFieldDictionary isKindOfClass:[NSDictionary class]])
    {
        NetLog(@"请求头数据有误，请检查！");
        return;
    }
    NSArray *keyArray = httpHeaderFieldDictionary.allKeys;
    
    if (keyArray.count <= 0)
    {
        NetLog(@"请求头数据有误，请检查！");
        return;
    }
    
    for (NSInteger i = 0; i < keyArray.count; i ++)
    {
        NSString *keyString = keyArray[i];
        NSString *valueString = httpHeaderFieldDictionary[keyString];
        [NetShareManager setValue:valueString forKey:keyString];
    }

}

@end
